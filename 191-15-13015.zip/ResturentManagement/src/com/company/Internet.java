package com.company;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Internet {
    private static final String BASE_URL = "jdbc:mysql://localhost:3306/resturant";
    private static final String userName = "root";
    private static final String password = "";
    public static Connection Con() throws SQLException {
        /*Class.forName("com.mysql.jdbc.Driver");*/
        Connection connection = DriverManager.getConnection(BASE_URL,userName,password);
        if (connection != null){
            System.out.println("the system is connected with the database");
        }else {
            System.out.println("The systtem connot connect to the database");
        }
        connection.close();
        return connection;
    }
}
