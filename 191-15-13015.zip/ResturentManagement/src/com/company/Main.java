package com.company;

import java.sql.SQLException;
import java.util.Locale;
import java.util.Scanner;   

public class Main {

    public static void main(String[] args) {
	// now i am going to ask the use to give the permission to start the application..///
        try {
            showTheMenue();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    private static boolean showTheMenue() throws SQLException {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter yes to start the application or press No to exit ");
        String userInput = input.nextLine();
        boolean chose = false;
        if (userInput.equals("Yes")){
            chose= true;
            System.out.println("the aplication is running");
            System.out.println("1.Log in");
            System.out.println("2.Registration");
            System.out.println("In the future");
            int choseO = input.nextInt();
            switch (choseO){
                case 1:
                    User user = new User();
                    System.out.println("Enter your name");
                    input.nextLine();
                    String name = input.nextLine();
                    System.out.println("Enter your password");
                    String password = input.nextLine();
                    user.loginUser(name,password);
                    break;
                case 2:
                    user = new User();
                    System.out.println("Enter your name");
                    input.nextLine();
                    name = input.nextLine();
                    System.out.println("Enter your password");
                    password = input.nextLine();
                    user.registraUser(name,password);
                    break;

            }
        }else {
            System.out.println("the aplication is stoped");
        }

        return chose;
    }
}
