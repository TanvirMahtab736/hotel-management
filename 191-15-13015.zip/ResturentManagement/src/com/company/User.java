package com.company;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class User {
    private int id;
    private String name;
    private String email;
    private String fullName;
    private String pasWord;

    public User() {
    }

    public User(String name, String pasWord) {
        this.name = name;
        this.pasWord = pasWord;
    }

    public User(String name, String email, String fullName, String pasWord) {
        this.name = name;
        this.email = email;
        this.fullName = fullName;
        this.pasWord = pasWord;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPasWord() {
        return pasWord;
    }

    public void setPasWord(String pasWord) {
        this.pasWord = pasWord;
    }

    public void loginUser(String name, String password) {
        Connection connection = null;
        try {
            connection = Internet.Con();
            ///now i am going to ocrete the basic select statement....///
            String sql = "SELECT * FROM Users";
            ///now i am going to connect to the statment...//
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(sql);
            String userName = result.getString(2);
            String userPassword = result.getString(3);
            if (name.equals(userName) && password.equals(userPassword)){
                System.out.println("Welcome to our resturant");
            }else {
                System.out.println("The pass word is wrong");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }



        /*if (this.name.equals(name)){
            if (this.pasWord == pasWord){
                System.out.println("Welcome to our resturant");
            }else {
                System.out.println("The pass word is wrong");
            }
        }*/
    }

    public void registraUser(String name, String password) {

    }
}
/*CREATE TABLE `info` (
    `client_id` int(11) NOT NULL AUTO_INCREMENT,
    `foodname` varchar(45) NOT NULL,
            PRIMARY KEY (`client_id`)
);*/
